# phoundry-ui — component/props cheat sheet

**Note:** Category folder paths below are relative to the installed package root (typically `node_modules/phoundry-ui/`). The published library lives under `dist/`.

Package `phoundry-ui`. Svelte 5 runes. `+` = spreads native element attrs where typed.

## Abbrev (token‑saving; match source `Props`)

onch=onchange, oninp=oninput, ph=placeholder, var=variant, dis=disabled, ro=readonly, desc=description, orient=orientation, indet=indeterminate, selInd=selectedIndicator, clear=clearable, req=required, inv=invalid, err=error, ac=autocomplete, btnLayout=buttonLayout, showVal=showValue, valFmt=valueFormatter, viewTrans=viewTransition, dir=direction, defSize=defaultSize, handleSz=handleSize, headSel=headingSelector, offTop=offsetTop, tgtOff=targetOffset, onCh=onChange, getCur=getCurrentAnchor, onnav=onnavigate, sep=separator, maxVis=maxVisible, minH=minHeight, maxH=maxHeight, dep=deprecated.

## Buttons

**Path:** `dist/components/buttons/`

| Cmp            | Desc                   | Props                                                                                                                                                                         |
| -------------- | ---------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Button         | Btn/link               | `variant?,size?,icon?,iconPosition?,iconOnly?,loading?,active?,children?,element?,title?,onclick?,href?,target?,rel?,noTooltip?,tooltipPlacement?,class?:ClassValue` +button |
| ButtonDropdown | Btn opens ctx menu     | `items,placement?,showArrow?,singleClickAction?` +inlined Button minus onclick                                                                                                |
| ButtonGroup    | Inset rounded segments | `variant?,size?,class?:ClassValue,items:ButtonGroupItem[]` (`label,icon?,iconOnly?,active?,disabled?,loading?,onclick?`) +div                                                 |

## Inputs

**Path:** `dist/components/inputs/`

| Cmp            | Desc            | Props                                                                                                                                                                  |
| -------------- | --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| TextInput      | 1-line          | `value?,onch?,oninp?,type?,ph?,size?,var?,dis?,ro?,icon?,prefix?,fixedPrefixW?,prefixBg?,suffix?,suffixBg?,clear?,class?,id?,name?,ac?,element?` bind `element` +input |
| Textarea       | Multi-line      | `value?,onch?,oninp?,ph?,rows?,resize?,size?,var?,dis?,ro?,class?,id?,name?,element?` bind `element` +textarea                                                         |
| Select         | Portal dropdown | `options,value,onch,ph?,size?,dis?,class?,var?,shrink?,clear?,req?,inv?,err?,id?,name?,selInd?,element?` bind `element` +btn                                           |
| NumberInput    | +/- numeric     | `value,onch,min?,max?,step?,size?,width?,btnLayout?,dis?,class?,id?,name?,element?` bind `element` +input                                                              |
| ButtonCheckbox | Checkbox+btn    | `checked,onch?,dis?,size?,class?,variant?` bind `checked` +button                                                                                                      |
| Checkbox       | Checkbox+lbl    | `checked,onch?,indet?,dis?,size?,label?,desc?,class?,id?,name?,element?` bind `element` +rest                                                                          |
| StatusCheckbox | Multi-state chk | `activeKey,states?,fallbackChar?,dis?,size?,ariaLabelPrefix?,onch?,class?,element?` bind `activeKey,element` +rest                                                     |
| CheckboxToggle | Switch          | `checked,onch?,dis?,size?,label?,desc?,class?,id?,name?,element?` bind `element` +rest                                                                                 |
| RadioGroup     | Radio set       | `options,value,onch,name?,orient?,size?,dis?,class?`                                                                                                                   |
| Slider         | Range           | `value,onch,min?,max?,step?,ticks?,size?,showVal?,valPos?,valFmt?,dis?,class?,id?,name?,element?` bind `element` +input                                                |

## Form

**Path:** `dist/components/form/`

| Cmp       | Desc              | Props                                                                |
| --------- | ----------------- | -------------------------------------------------------------------- |
| FormField | Label/err wrapper | `label?,description?,error?,required?,disabled?,id?,class?,children` |

## Display

**Path:** `dist/components/display/`

| Cmp                | Desc                     | Props                                                                                                                     |
| ------------------ | ------------------------ | ------------------------------------------------------------------------------------------------------------------------- |
| Badge              | Status chip              | `variant?,size?,icon?,dot?,class?,children?`                                                                              |
| Avatar             | Circle img/initials/icon | `src?,alt?,initials?,icon?,size?,status?,class?`                                                                          |
| CodeBlock          | Shiki highlight          | `code,lang?,class?,colorSchemeRoot?`                                                                                      |
| CollapsibleSection | Accordion-ish            | `title,defaultOpen?,open?,onToggle?,onOpenChange?,children,icon?,extraButtons?,contentPadding?,fullHeight?,titleVariant?` |
| DropZone           | File drag                | `ondrop,accept?,disabled?,class?,children?,active?`                                                                       |
| EmptyState         | Empty view               | `icon?,title,description?,action?,size?,class?`                                                                           |
| Kbd                | Key cap                  | `keys,size?,class?`                                                                                                       |
| ProgressBar        | Bar/indet                | `value?,variant?,size?,showValue?,class?`                                                                                 |
| Separator          | Divider                  | `orientation?,label?,children?,class?`                                                                                    |
| Skeleton           | Loading blk              | `variant?,width?,height?,lines?,class?`                                                                                   |

## Layout

**Path:** `dist/components/layout/`

| Cmp          | Desc                   | Props                                                                               |
| ------------ | ---------------------- | ----------------------------------------------------------------------------------- |
| Tabs         | Tab bar+panel          | `items,value,onch,onclose?,orient?,var?,size?,class?,viewTrans?,tab?,panel?`        |
| SplitPane    | Resizable 2-pane       | `dir?,size?,defSize?,min?,max?,onresize?,handleSz?,class?,first,second` bind `size` |
| NoiseOverlay | SVG feTurbulence grain | `opacity?,zIndex?,baseFrequency?,numOctaves?,seed?,blendMode?,position?,class?`     |

## Nav

**Path:** `dist/components/navigation/`

| Cmp        | Desc             | Props                                                                                                |
| ---------- | ---------------- | ---------------------------------------------------------------------------------------------------- |
| Anchor     | TOC / scroll spy | `items?,target?,headSel?,dir?,offTop?,tgtOff?,bounds?,affix?,replace?,onCh?,onclick?,getCur?,class?` |
| Breadcrumb | Trail            | `items,onnav?,sep?,maxVis?,size?,class?`                                                             |

## Ratings / tags

**Paths:** `dist/components/ratings/`, `dist/components/tags/`

| Cmp        | Desc        | Props                                                                      |
| ---------- | ----------- | -------------------------------------------------------------------------- |
| StarRating | Stars       | `rating?,ro?,size?,max?,allowHalf?,onch?,class?`                           |
| TagEditor  | Chips+input | `tags,ph?,onch,onChange?(dep),dis?,maxTags?,validate?,suggestions?,class?` |

## Advanced

**Path:** `dist/components/advanced/`

| Cmp                | Desc                 | Props                                                                                                     |
| ------------------ | -------------------- | --------------------------------------------------------------------------------------------------------- |
| ColorPicker        | HSV+fmt              | `value,onch,format?,showInput?,showPresets?,presets?,dis?,size?,class?`                                   |
| DatePicker         | Field+popover cal    | `value?,rangeStart?,rangeEnd?,mode?,onch?,onrangechange?,minDate?,maxDate?,dis?,class?,ph?,weekStartsOn?` |
| DatePickerAdvanced | Inline cal           | `value?,onch?,minDate?,maxDate?,dis?,class?,weekStartsOn?,showToggles?` bind `value`                      |
| TimePicker         | 12h or HH:MM:SS dur  | `mode?('time'|'duration'),hour?,minute?,second?,onch?,dis?,class?` bind `hour,minute,second`              |
| Sheet              | Drawer               | `open,onclose,side?,size?,title?,closeOnBackdrop?,closeOnEscape?,showCloseButton?,class?,children`        |
| Stepper            | Wizard steps         | `steps,currentStep,clickable?,onstepchange?,orientation?,showNumbers?,class?,step?`                       |
| KanbanBoard        | DnD columns          | `columns,onmove?,onadd?,card?,columnHeader?,class?`                                                       |
| RichTextEditor     | contenteditable HTML | `value,onch,ph?,toolbar?,dis?,minH?,maxH?,class?`                                                         |

> **Block markdown editing:** Use the **`phormat`** package (`PhormatEditor`) — not shipped in phoundry-ui.

## Data table

**Path:** `dist/data/data-table/` (cell editors: `dist/data/data-table/cells/`)

| Cmp             | Desc                | Props                                                                                                                                                                                                                                                                          |
| --------------- | ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| DataTable       | Sort/select/virtual | `data,columns,getRowId?,onSortChange?,onSelectionChange?,onRowClick?,onRowDblClick?,onCellChange?,selectable?,rowHeight?,maxHeight?,virtualScroll?,striped?,bordered?,compact?,wrapCells?,rowDividers?,groupBy?,groupHeaderHeight?,groupCell?,class?,cell?,headerCell?,empty?` |
| CellText        | inline edit         | `value,onch,ph?`                                                                                                                                                                                                                                                               |
| CellNumber      |                     | `value,onch,ph?,format?`                                                                                                                                                                                                                                                       |
| CellBoolean     |                     | `value,onchange,label?`                                                                                                                                                                                                                                                        |
| CellRating      |                     | `value,onch,max?`                                                                                                                                                                                                                                                              |
| CellSelect      |                     | `value,options,onchange,onCreate?,onUpdate?,onDelete?,placeholder?`                                                                                                                                                                                                            |
| CellMultiSelect |                     | same shape as CellSelect                                                                                                                                                                                                                                                       |
| CellDate        | epoch ms            | `value,onchange,valueEnd?,includeTime?,dateRange?,placeholder?`                                                                                                                                                                                                                |
| CellUrl         |                     | `value,onch,ph?`                                                                                                                                                                                                                                                               |
| CellRelation    |                     | `items,onch,onSearch?,ph?`                                                                                                                                                                                                                                                     |

Table logic: `createTable` + column/cell types → **Data (headless)** below.

## Tree

**Path:** `dist/data/tree-view/`

| Cmp      | Desc           | Props                                                                                                                                                                                      |
| -------- | -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| TreeView | Hierarchy list | `nodes,selected?,expanded?,onselect?,onexpand?,onactivate?,multiSelect?,showIndentGuides?,indentWidth?,itemHeight?,virtualScroll?,maxHeight?,class?,nodeContent?` bind `selected,expanded` |

Virtual list: `createVirtualList` → **Data (headless)** below (`dist/data/virtual-list/`).

## Overlay mounts (root layout)

**Path:** `dist/overlay/` (subfolders: `modal/`, `context-menu/`, `popover/`, `tooltip/`, `command-bar/`, `toast/`, `tour/`; root includes `setup-overlays.js`)

| Cmp                  | Desc               | Props                                                                                                                                                                                         |
| -------------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ModalOverlay         | Modal stack host   | _(none — uses modal mgr)_                                                                                                                                                                     |
| ModalStackLayer      | Single stacked dlg | `modal,isTop,zIndex,onBackdropClick,onClose` _(internal)_                                                                                                                                     |
| Modal                | Card in stack      | `title,onClose,closeOnBackdrop?,size?,width?(dep),noTitle?,children`                                                                                                                          |
| ConfirmDialog        | builtin            | `title,message,confirmLabel?,cancelLabel?,danger?,onClose(boolean)`                                                                                                                           |
| PromptDialog         | builtin            | `title,message?,defaultValue?,placeholder?,confirmLabel?,cancelLabel?,onClose` (string or null)                                                                                               |
| AlertDialog          | builtin            | `title,message,confirmLabel?,onClose`                                                                                                                                                         |
| ContextMenuOverlay   | ctx menu host      | _(none — uses ctx API)_                                                                                                                                                                       |
| ContextMenu          | menu session       | `items,x,y,anchor?,side?,ariaLabel?,onClose`                                                                                                                                                  |
| ContextMenuPanel     | menu surface       | Session-owned root/child panel _(internal)_                                                                                                                                                   |
| ContextMenuItem      | row                | `item`                                                                                                                                                                                        |
| ContextMenuSubmenu   | submenu trigger    | `item,showIconGutter?,active?` plus session callbacks                                                                                                                                         |
| ContextMenuGroup     | icon row           | `item`                                                                                                                                                                                        |
| ContextMenuLabel     | hdr                | `label`                                                                                                                                                                                       |
| ContextMenuSeparator | rule               | _(none)_                                                                                                                                                                                      |
| ComboboxOverlay      | combobox host      | _(none — uses combobox API)_                                                                                                                                                                  |
| ComboboxPanel        | option panel       | `cbState` (internal)                                                                                                                                                                          |
| ComboboxOptionItem   | option row         | `option,query,active,selected,size,showIconGutter,optionSnippet?,onselect,onhover` (internal)                                                                                                 |
| OverlayListItem      | shared row         | `label?,labelHtml?,description?,icon?,showIconGutter?,active?,selected?,danger?,disabled?,size?,leading?,trailing?,children?` +rest                                                           |
| Popover              | frosted float      | `open?,onOpenChange?,placement?,offset?,flip?,dismissible?,class?` (layout only; chrome=`.phi-frosted-panel`),`trigger?,children?` bind `open`                                                |
| PopoverOverlay       | programmatic host  | frosted shell + `children?` default body; `getPopoverManager().open({ anchor, … })`                                                                                                           |
| TooltipOverlay       | global tips        | `shouldSuppress?()`; follows cursor by default or anchors via `TooltipPlacement`                                                                                                              |
| CommandBar           | palette UI         | `commands,config,subgroups?,recentCommandIds?,placeholder?` + `getCommandBarState()`                                                                                                          |
| CommandBarItem       | row                | `entry,isSelected,onSelect`                                                                                                                                                                   |
| ToastOverlay         | toast region       | `position?`                                                                                                                                                                                   |
| ToastItem            | single toast       | `toast,onDismiss`                                                                                                                                                                             |
| Tour                 | spotlight tour     | `steps,open?,current?,onClose?,onChange?,mask?,type?,gap?,arrow?,placement?,zIndex?,dismissOnOutsideClick?,scrollIntoViewOptions?,disabledInteraction?,indicatorsRender?` bind `open,current` |

## Non-component utilities

Barrel: `phoundry-ui` (same as components). **Path:** `dist/` (`index.js` / `index.d.ts`).

| Area                | Symbols                                                                                                                   | Role                                                       |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------- |
| **Types**           | `ComponentSize`, `BaseProps`, `InputProps`                                                                                | Shared prop shapes                                         |
| **Icons**           | `PhiIcons`                                                                                                                | `as const` map of Iconify ids used by primitives           |
| **Icons (subpath)** | `phoundry-ui/icons` — `registerPhoundryMono`, `registerPhoundryColored`, `registerPhoundryIcons`, collection JSON exports | Custom Iconify collections; register explicitly at startup |

### Theme

**Path:** `dist/theme/` (built-ins: `dist/theme/builtin/`)

| Symbol                                               | Role                                                                                                                                                                                   |
| ---------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ThemeManager`, `getThemeManager()`                  | Reactive theme manager (class + singleton accessor)                                                                                                                                    |
| `ThemeVariables`, `ThemeDefinition`, `ThemeSettings` | Types                                                                                                                                                                                  |
| `builtinThemes`                                      | `ThemeDefinition[]` of all presets                                                                                                                                                     |
| Named exports                                        | `defaultDarkTheme`/`defaultLightTheme`, solarized/nord/rose-pine/gruvbox/everforest/dracula/catppuccin/tokyo-night/one-dark/kanagawa/night-owl/ayu`variants (see`dist/theme/index.js`) |

### Shortcuts

**Path:** `dist/utilities/shortcuts/`

| Symbol                                                                                                                                                | Role                                                                                                                                                                                                                |
| ----------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ShortcutManager`, `createShortcutManager`, `getShortcutManager`                                                                                      | Registry + global accessor                                                                                                                                                                                          |
| `formatShortcut`, `formatParsedShortcut`, `formatModifiersOnly`                                                                                       | Display strings                                                                                                                                                                                                     |
| `parseShortcut`, `matchesEvent`, `normalizeKey`, `resolveDefinition`, `canonicalizeShortcut`, `getCanonicalShortcut`, `getPlatform`, `detectPlatform` | Parse / match / platform                                                                                                                                                                                            |
| Types                                                                                                                                                 | `ShortcutPlatform`, `PlatformShortcuts`, `ShortcutDefinition`, `ParsedShortcut`, `ShortcutRegistration`, `ShortcutOverrides`, `ShortcutConflict`, `ShortcutSection`, `ShortcutSubsection`, `ShortcutManagerOptions` |

### Focus

**Path:** `dist/utilities/focus/`

| Symbol                 | Role                                                                                                                 |
| ---------------------- | -------------------------------------------------------------------------------------------------------------------- |
| `createFocusTrap`      | Svelte action factory; types: `FocusTrapOptions`, `FocusTrap`, `FocusTrapDeactivateOptions`, `FocusTrapActionParams` |
| `createRovingTabIndex` | Roving tabindex helper; types: `RovingTabIndexOptions`, `RovingTabIndex`                                             |

### Drag–drop

**Path:** `dist/utilities/drag-drop/`

| Symbol          | Role                                                                                                                |
| --------------- | ------------------------------------------------------------------------------------------------------------------- |
| `dndList`       | List attachment factory; options: `DndListOptions`; registers drop zone with `onReorder` / `onReceive` / `onRemove` |
| `dndItem`       | Item attachment factory; options: `DndItemOptions`                                                                  |
| `DndGhost`      | Presentational: drag preview (mount once per app surface using DnD)                                                 |
| `DndIndicator`  | Presentational: insertion marker; optional `contentInsetLeft` skips a left grip column (px)                         |
| `getDndManager` | Singleton accessor (advanced)                                                                                       |
| Types           | List option/result types (`DndListOptions`, `DndItemOptions`, `DndItemData`, …)                                     |

Nested document-tree DnD lives in **Phormat** (`editor/dnd/`), not in this package.

### Data (headless)

**Paths:** `dist/data/virtual-list/`, `dist/data/data-table/`, `dist/data/tree-view/`

| Symbol              | Role                                                                                                                     |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| `createVirtualList` | Windowed list; types: `VirtualItem`, `VirtualListOptions`, `VirtualListInstance`                                         |
| `createTable`       | Headless table state for `DataTable`; types: `ColumnDef`, `SortState`, `ResolvedColumn`, `TableOptions`, `TableInstance` |
| Cell types          | `CellOption`, `CellRelationItem`, `CellConfig`, `CellType`                                                               |

### Overlay / shell

**Path:** `dist/overlay/`

| Symbol                                    | Role                                                                                                                                                                                                                                                                                              |
| ----------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `setupOverlays(opts?)`                    | One-shot: `provideContextMenu` + `provideCombobox` + `providePopover` + `provideModalManager` + `getToastManager` + `getTooltipManager` + `getCommandBarState` → `{ contextMenu, combobox, popover, toast, tooltip, commandBar }`; opts: `maxToasts?`                                             |
| `provideModalManager`                     | Init stack + context                                                                                                                                                                                                                                                                              |
| `useModalManagerAPI`                      | Modal API from Svelte context (`open`, `close`, `closeAll`, `confirm`, `prompt`, `alert`, `stack`, `hasModals`)                                                                                                                                                                                   |
| `getModalManager`                         | Same API outside init (after provide)                                                                                                                                                                                                                                                             |
| `setBuiltinDialogs`                       | Wire Confirm/Prompt/Alert components (normally from `ModalOverlay`)                                                                                                                                                                                                                               |
| Types                                     | `ModalEntry`, `ModalComponentProps`, `OpenModalOptions`, `ConfirmOptions`, `PromptOptions`, `AlertOptions`, `ModalManagerAPI`                                                                                                                                                                     |
| `provideContextMenu`, `useContextMenuAPI` | Ctx menu store: `open(items,x,y,opts?)`, `close`, `bumpTick`, `state`, `tick`                                                                                                                                                                                                                     |
| `contextMenu`                             | Svelte **attachment** `{@attach contextMenu({ api, items })}`                                                                                                                                                                                                                                     |
| `provideCombobox`, `useComboboxAPI`       | Combobox overlay store: `open(options)`, `close`, `setQuery`, `select`, `create`, `bumpTick`, `configure`, `state`, `tick`, `query`, `isOpen`                                                                                                                                                     |
| `combobox`                                | Svelte **attachment** `{@attach combobox({ api, options, value, onchange, openOn?, shouldOpen?, onInteraction?, searchMode? })}`                                                                                                                                                                  |
| Combobox types                            | `ComboboxOption`, `ComboboxOptionsSource`, `ComboboxSearchMode`, `ComboboxValue`, `ComboboxConfig`, `ComboboxDefaults`, `ComboboxOpenOptions`, `ComboboxState`, `ComboboxAPI`, `ComboboxOptions`, `ComboboxOpenOn`, `ComboboxAttachmentContext`                                                   |
| Combobox logic                            | `filterOptions`, `groupOptions`, `shouldShowCreate`, `highlightMatch`, `toValueArray`, `COMBOBOX_SEARCH_DEBOUNCE_MS`; type `GroupedOptions`                                                                                                                                                       |
| Context types                             | `MenuItem`, `ActionMenuItem`, `BooleanMenuItem`, `SubmenuMenuItem`, `GroupMenuItem`, `SeparatorMenuItem`, `LabelMenuItem`, `CustomMenuItem`, `MenuItemsSource`, `MenuAnchor`, `ContextMenuState`, `ContextMenuAPI`, `OpenMenuOptions`, `ContextMenuItems`                                         |
| `getToastManager(max?)`                   | `add`, `dismiss`, `clear`, `success`/`error`/`warning`/`info`; types: `ToastEntry`, `ToastOptions`, `ToastVariant`, `ToastPosition`, `ToastAction`                                                                                                                                                |
| `getTooltipManager`                       | `show(el,content,placement?)`, `hide`, `hideImmediately`; getters `visible`, `content`, `element`, `placement`                                                                                                                                                                                    |
| `tooltip`                                 | Svelte **attachment** `{@attach tooltip({ content, placement? })}` or string; types `TooltipOptions` and `TooltipPlacement` (`follow-cursor` plus every `PopoverPlacement`)                                                                                                                       |
| `getCommandBarState`                      | Singleton `CommandBarState`: `configure`, `open`/`close`/`toggle`, `query`, `selectedIndex`, `selectPrevious`/`selectNext`, `executeSelected`; types `CommandBarCommand`, `CommandBarConfig`, `CommandBarSubgroup`, `CommandBarEntry`, `CommandBarSubgroupContentContext`, `isCommandBarSubgroup` |
| `computePosition`                         | Float positioning helper (popover/tour); types `PopoverPlacement`, `PopoverPosition`, `PopoverSide`                                                                                                                                                                                               |
| `getPopoverManager` / `providePopover`    | Programmatic popover singleton + context API; `setupOverlays()` registers both                                                                                                                                                                                                                    |
| Tour types                                | `TourStepDef`, `TourPlacement`                                                                                                                                                                                                                                                                    |
